# Hardware

PCB design has not started yet. Current builds are breadboard prototypes — see
[`../docs/wiring.md`](../docs/wiring.md).

## Planned

**PicoGSC** — main board:
- 26-pin PowerBook interconnect
- 2× 74LVC245A (TSSOP)
- RP2350 (module first, bare chip on a later revision)
- HDMI connector with proper 100 Ω differential routing

**PicoGSC Kit** — the above plus a modern panel for the original lid:
- 8.9" 2560x1600 IPS panel (exactly 4x 640x400, so integer scaling is possible)
- HDMI-to-MIPI driver board
- 3D-printed bezel (~192x120 mm active area vs. ~211x132 mm original,
  leaving roughly 10 mm per side)

Open questions before any of this is routed:
- how much current the PowerBook's display rail can actually supply
- whether the scaler board does nearest-neighbour or bilinear interpolation
  (bilinear would smear the 1-pixel dithering that makes the image sharp)

Designs will be released under CERN-OHL.
