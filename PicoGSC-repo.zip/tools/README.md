# Tools

## `pgm2h.py`

Converts a PGM capture into a C header, so a real frame can be compiled into
the firmware and displayed without a PowerBook attached. Good for verifying the
output path (palette, nibble order, centring) in isolation.

```sh
python3 pgm2h.py captures/desktop.pgm > frame_data.h
```

## Cleaning a serial log

The `p` command prints the PGM between markers. To cut it out of a terminal log:

```sh
sed -n '/### PGM BEGIN ###/,/### PGM END ###/p' capture.log | sed '1d;$d' > frame.pgm
```

**Never redirect into the file you are reading from** — the shell truncates the
output file before `sed` starts, leaving you with 0 bytes and no original.

Sanity check before doing anything else:

```sh
wc -c frame.pgm                                  # must not be 0
head -1 frame.pgm                                # must be exactly: P2
grep -v '^#' frame.pgm | tail -n +4 | wc -w      # must be 256000
```

## Viewing

PGM is already an image format — most viewers open it directly. To convert:

```sh
magick frame.pgm -negate frame.png       # -negate: raw bus values are inverted
magick frame.pgm -negate -scale 200% frame.png
```
