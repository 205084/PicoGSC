/*
 * picogsc.ino — PicoGSC v0.2
 * Live-Videobruecke: Apple PowerBook 180 GSC-Bus -> HDMI/DVI
 *
 * Projekt : PicoGSC   |   https://picogsc.com
 * Lizenz  : MIT (Code)
 *
 * Der GSC ("Gray Scale Controller") ist der Grafikcontroller der PowerBooks
 * 160/165/180 — laut MAME-Quellen ein Chips & Technologies 65210. Sein
 * 26-poliges Panel-Interface ist von Apple nie dokumentiert worden; die hier
 * verwendete Busspezifikation stammt aus eigener Messung (s. Anhang unten).
 *
 * Zielboard : Adafruit Feather RP2350 HSTX (+PSRAM, hier UNGENUTZT — s.u.)
 * Toolchain : arduino-cli / Arduino IDE, earlephilhower Core, Upload: Picotool
 * Library   : "Adafruit DVI HSTX" (Library Manager) + Adafruit GFX
 *
 * !! Die Library uebertaktet den Chip allein durchs Include auf 264 MHz.
 * !! PSRAM in diesem Sketch NICHT verwenden (132-MHz-QMI > APS6404-Spec).
 * !! Capture-PIO laeuft dadurch mit 264 MHz — wait-Logik unveraendert gueltig.
 *
 * ================= VERDRAHTUNG (= Protokoll v2) =========================
 *   FPDATA0..7 = GP22..GP29 | CL2=GP4 | CL1=GP5 | FLM=GP6
 *   DISP_BLANK = GP9 | M_F = GP0      (nur CPU-Diagnose)
 *   HSTX/DVI   = GP12..19 (Library) | GESPERRT: GP2/3/8/10/11/21
 *   Pegelwandlung: 2x 74LVC245A, VCC = 3,3 V, DIR=H, /OE=L.
 *   STN_MODE (PB-Pin 23) auf GND -> Video laeuft ohne angeschlossenes Panel.
 *
 * ================= RAM-BILANZ (520 kB SRAM) =============================
 *   DVHSTX8-Framebuffer 640x480x1B = 307.200 B (Heap, in begin())
 *   Capture-Puffer 4bpp             = 128.000 B (BSS)
 *   -> Verify-Zweitpuffer ENTFAELLT; 'v' vergleicht CRCs.
 *   Compiler-Warnung ">50% dynamic memory" ist HIER NORMAL.
 *
 * ================= ANZEIGE ==============================================
 *   640x480@60, 8bpp-Palette. Frame 640x400 mittig, 40 Zeilen Rand o/u.
 *   Palette 0..15 = Graustufen MIT QuickDraw-Umsetzung: am GSC bedeutet ein
 *   hoher Nibble-Wert DUNKEL (QuickDraw-Konvention). Die Umkehrung fuer
 *   moderne Displays passiert in der Palette, nicht in den Daten — der
 *   Capture-Puffer und damit 'p'/'d'/'D' bleiben ROH.
 *   Single-Buffer: Tearing ist in v0.2 NORMAL. Dual-Core kommt in v0.3.
 *
 * ================= BEDIENUNG (USB-Seriell, optional) ====================
 *   c Capture einzeln | v Verify (2x Capture, CRC-Vergleich, Bild statisch!)
 *   s Statistik | d/D Hexdump kurz/voll | l <n> Zeile n | p PGM-Export (roh)
 *   n Nibble-Reihenfolge | e Flanke FALL/RISE | i M_F/BLANK-Pegel + FLM
 *   t Testbild an den Monitor (Graukeil + 1px-Schachbrett) — geht OHNE PB
 *   g Live-Bridge an/aus | h Hilfe
 *   Die Bridge laeuft auch komplett ohne PC am USB.
 */

#include <Adafruit_dvhstx.h>
#include <Arduino.h>
#include "hardware/pio.h"
#include "hardware/dma.h"
#include "hardware/gpio.h"

#define PICOGSC_VERSION "0.2"

// ---------- Geometrie ----------
#define LINE_BYTES   320
#define LINES        400
#define FRAME_BYTES  (LINE_BYTES * LINES)   // 128 000
#define FRAME_WORDS  (FRAME_BYTES / 4)      //  32 000
#define OUT_W        640
#define OUT_H        480
#define Y_OFF        ((OUT_H - LINES) / 2)  // 40

// ---------- Pins ----------
#define PIN_DATA_BASE 22
#define PIN_CL2        4
#define PIN_CL1        5
#define PIN_FLM        6
#define PIN_BLANK      9
#define PIN_MF         0

// ---------- Anzeige ----------
DVHSTX8 display(ADAFRUIT_FEATHER_RP2350_CFG, DVHSTX_RESOLUTION_640x480);

// Palette-Sonderfarben (Index 16+)
#define C_GREEN  16
#define C_RED    17
#define C_YELLOW 18
#define C_BOX    19

// >>> API-ANPASSUNGSPUNKT 1: Palettenfarbe setzen <<<
// Falls der Compiler hier meckert, in dvhstx.hpp nachsehen; Kandidaten:
//   display.setColor(idx, ((uint32_t)r<<16)|((uint32_t)g<<8)|b);
//   display.set_palette_colour(idx, r, g, b);
static inline void pal_set(uint8_t idx, uint8_t r, uint8_t g, uint8_t b) {
  display.setColor(idx, r, g, b);
}

// >>> API-ANPASSUNGSPUNKT 2: Framebuffer-Zugriff <<<
// 0 setzen, falls getBuffer() nicht existiert -> drawPixel-Fallback (langsamer).
#define USE_GETBUFFER 1

// ---------- PIO-Programme ----------
// Quelle (IN-Base = GP22, wait-Indizes modulo 32):
//   wait 0 pin 16 ; FLM low   (GP6)
//   wait 1 pin 16 ; FLM rising  = Frame-Marker
//   wait 0 pin 15 ; CL1 low   (GP5)
//   wait 1 pin 15 ; CL1 rising  = Zeilengrenze, ab hier Byte 0
// .wrap_target
//   wait 1 pin 14 ; CL2 high  (GP4)
//   wait 0 pin 14 ; CL2 falling edge   <- Sharp-Konvention
//   in pins, 8    ; FPDATA[0..7], Autopush bei 32 bit
// .wrap
static const uint16_t prog_fall_instr[] = {
  0x2030, 0x20b0, 0x202f, 0x20af,
  0x20ae, 0x202e, 0x4008
};
static const uint16_t prog_rise_instr[] = {   // CL2-Flanken getauscht
  0x2030, 0x20b0, 0x202f, 0x20af,
  0x202e, 0x20ae, 0x4008
};
static const struct pio_program prog_fall = {
  .instructions = prog_fall_instr, .length = 7, .origin = -1
};
static const struct pio_program prog_rise = {
  .instructions = prog_rise_instr, .length = 7, .origin = -1
};

// ---------- Zustand ----------
static PIO  pio = pio0;
static uint sm  = 0;
static int  dma_ch = -1;
static uint prog_offset = 0;
static bool edge_fall    = true;
static bool nib_hi_first = true;
static bool live_mode    = true;      // Bridge laeuft ab Boot

static uint32_t framebuf[FRAME_WORDS];
static uint32_t words_captured = 0;
static bool     last_complete  = false;
static bool     last_overrun   = false;

enum ScreenState { SCR_NONE, SCR_NOSIG, SCR_LIVE, SCR_TEST };
static ScreenState screen = SCR_NONE;
static uint32_t frames_ok = 0, frames_to = 0;
static uint32_t fps_count = 0, fps_last_ms = 0, fps_shown = 0;

// ---------- PIO/DMA ----------
static void load_program() {
  const struct pio_program *p = edge_fall ? &prog_fall : &prog_rise;
  prog_offset = pio_add_program(pio, p);
  pio_sm_config c = pio_get_default_sm_config();
  sm_config_set_in_pins(&c, PIN_DATA_BASE);
  sm_config_set_in_shift(&c, true, true, 32);
  sm_config_set_fifo_join(&c, PIO_FIFO_JOIN_RX);
  sm_config_set_clkdiv(&c, 1.0f);
  sm_config_set_wrap(&c, prog_offset + 4, prog_offset + 6);
  pio_sm_init(pio, sm, prog_offset, &c);
}
static void unload_program() {
  pio_sm_set_enabled(pio, sm, false);
  pio_remove_program(pio, edge_fall ? &prog_fall : &prog_rise, prog_offset);
}
static void setup_capture_hw() {
  for (uint p = PIN_DATA_BASE; p < PIN_DATA_BASE + 8; p++) {
    gpio_init(p); gpio_set_dir(p, GPIO_IN); gpio_disable_pulls(p);
  }
  for (uint p = PIN_CL2; p <= PIN_FLM; p++) {
    gpio_init(p); gpio_set_dir(p, GPIO_IN); gpio_disable_pulls(p);
  }
  gpio_init(PIN_BLANK); gpio_set_dir(PIN_BLANK, GPIO_IN); gpio_disable_pulls(PIN_BLANK);
  gpio_init(PIN_MF);    gpio_set_dir(PIN_MF,    GPIO_IN); gpio_disable_pulls(PIN_MF);
  pio_sm_claim(pio, sm);
  load_program();
  dma_ch = dma_claim_unused_channel(true);
}

static bool capture_frame(uint32_t timeout_ms) {
  pio_sm_set_enabled(pio, sm, false);
  pio_sm_clear_fifos(pio, sm);
  pio_sm_restart(pio, sm);
  pio_sm_clkdiv_restart(pio, sm);
  pio_sm_exec(pio, sm, pio_encode_jmp(prog_offset));
  pio->fdebug = 1u << (PIO_FDEBUG_RXSTALL_LSB + sm);

  dma_channel_config dc = dma_channel_get_default_config(dma_ch);
  channel_config_set_transfer_data_size(&dc, DMA_SIZE_32);
  channel_config_set_read_increment(&dc, false);
  channel_config_set_write_increment(&dc, true);
  channel_config_set_dreq(&dc, pio_get_dreq(pio, sm, false));
  dma_channel_configure(dma_ch, &dc, framebuf, &pio->rxf[sm], FRAME_WORDS, true);

  pio_sm_set_enabled(pio, sm, true);
  uint32_t t0 = millis();
  while (dma_channel_is_busy(dma_ch)) {
    if (millis() - t0 > timeout_ms) {
      uint32_t remaining = dma_channel_hw_addr(dma_ch)->transfer_count;
      dma_channel_abort(dma_ch);
      pio_sm_set_enabled(pio, sm, false);
      words_captured = FRAME_WORDS - remaining;
      last_complete = false; last_overrun = false;
      return false;
    }
  }
  pio_sm_set_enabled(pio, sm, false);
  last_overrun = pio->fdebug & (1u << (PIO_FDEBUG_RXSTALL_LSB + sm));
  words_captured = FRAME_WORDS;
  last_complete = true;
  return true;
}

// ---------- Signalerkennung (CPU, ohne PIO) ----------
// ACHTUNG: Polling-Messung, verschluckt unter Last Flanken. Fuer die
// Statusanzeige gut genug, fuer echte Frequenzmessung Scope/LA benutzen.
static float flm_hz(uint32_t win_ms) {
  uint32_t edges = 0;
  bool last = gpio_get(PIN_FLM);
  uint32_t t0 = millis();
  while (millis() - t0 < win_ms) {
    bool now = gpio_get(PIN_FLM);
    if (now != last) { edges++; last = now; }
  }
  return (edges / 2.0f) * (1000.0f / win_ms);
}
static bool signal_present() { return flm_hz(50) > 20.0f; }

// ---------- Anzeige-Hilfen ----------
static void init_palette() {
  // 0..15: Graustufen, QuickDraw-Umsetzung (Busnibble 0 = weiss, 15 = schwarz)
  for (int i = 0; i < 16; i++) {
    uint8_t g = (15 - i) * 17;
    pal_set(i, g, g, g);
  }
  pal_set(C_GREEN,  40, 200,  40);
  pal_set(C_RED,   220,  50,  50);
  pal_set(C_YELLOW,220, 200,  40);
  pal_set(C_BOX,    35,  35,  35);
}

static void blit_frame() {
#if USE_GETBUFFER
  uint8_t *fb = display.getBuffer();
  const uint8_t *src = (const uint8_t *)framebuf;
  for (int y = 0; y < LINES; y++) {
    uint8_t *dst = fb + (uint32_t)(y + Y_OFF) * OUT_W;
    for (int x = 0; x < LINE_BYTES; x++) {
      uint8_t b = *src++;
      if (nib_hi_first) { *dst++ = b >> 4;   *dst++ = b & 0x0F; }
      else              { *dst++ = b & 0x0F; *dst++ = b >> 4;   }
    }
  }
#else
  const uint8_t *src = (const uint8_t *)framebuf;
  for (int y = 0; y < LINES; y++)
    for (int x = 0; x < LINE_BYTES; x++) {
      uint8_t b = *src++;
      uint8_t p1 = nib_hi_first ? (b >> 4) : (b & 0x0F);
      uint8_t p2 = nib_hi_first ? (b & 0x0F) : (b >> 4);
      display.drawPixel(2 * x,     y + Y_OFF, p1);
      display.drawPixel(2 * x + 1, y + Y_OFF, p2);
    }
#endif
}

static void draw_statusbar(const char *txt, uint8_t color) {
  display.fillRect(0, OUT_H - 14, OUT_W, 14, 15);
  display.setTextColor(color);
  display.setTextSize(1);
  display.setCursor(4, OUT_H - 11);
  display.print(txt);
}

static void draw_nosignal() {
  display.fillScreen(15);
  display.fillRect(140, 180, 360, 110, C_BOX);
  display.setTextColor(0);
  display.setTextSize(3);
  display.setCursor(196, 200);
  display.print("PicoGSC");
  display.setTextSize(2);
  display.setTextColor(C_RED);
  display.setCursor(190, 240);
  display.print("KEIN PB-SIGNAL");
  display.setTextSize(1);
  display.setTextColor(0);
  display.setCursor(168, 268);
  display.print("FLM still - PowerBook aus oder Kabel ab?");
  display.setCursor(250, 300);
  display.print("picogsc.com");
  screen = SCR_NOSIG;
}

static void draw_testpattern() {
  display.fillScreen(15);
  for (int i = 0; i < 16; i++)                 // Graukeil, Rohwerte 0..15
    display.fillRect(i * 40, Y_OFF, 40, 160, i);
  for (int y = 0; y < 160; y++)                // 1px-Schachbrett = Schaerfetest
    for (int x = 0; x < OUT_W; x++)
      display.drawPixel(x, Y_OFF + 200 + y, ((x ^ y) & 1) ? 15 : 0);
  draw_statusbar("PicoGSC TESTBILD | Keil 0..15 (roh) + 1px-Schachbrett | 'g' = Bridge", C_YELLOW);
  screen = SCR_TEST;
}

// ---------- CRC (FNV-1a) fuer Verify ohne Zweitpuffer ----------
static uint32_t frame_crc() {
  uint32_t h = 2166136261u;
  const uint8_t *b = (const uint8_t *)framebuf;
  for (uint32_t i = 0; i < FRAME_BYTES; i++) { h ^= b[i]; h *= 16777619u; }
  return h;
}

// ---------- CLI ----------
static void print_status_line() {
  Serial.printf("Bytes: %lu/%u | %s | Overrun: %s\r\n",
    (unsigned long)(words_captured * 4), FRAME_BYTES,
    last_complete ? "KOMPLETT" : "TIMEOUT",
    last_overrun ? "JA (evtl. Artefakt)" : "nein");
}
static void cmd_verify() {
  Serial.println("Verify: 2x Capture, CRC-Vergleich (statisches Bild!)...");
  if (!capture_frame(500)) { Serial.println("Frame 1: TIMEOUT."); return; }
  uint32_t c1 = frame_crc();
  if (!capture_frame(500)) { Serial.println("Frame 2: TIMEOUT."); return; }
  uint32_t c2 = frame_crc();
  if (c1 == c2) Serial.printf("CRCs identisch (%08lX). Kette steht.\r\n", (unsigned long)c1);
  else Serial.printf("CRC-Differenz: %08lX vs %08lX -> Bild bewegt, Masse, oder Flanke ('e').\r\n",
                     (unsigned long)c1, (unsigned long)c2);
}
static void cmd_stats() {
  print_status_line();
  if (!words_captured) return;
  uint32_t hist[16] = {0};
  const uint8_t *b = (const uint8_t *)framebuf;
  for (uint32_t i = 0; i < words_captured * 4; i++) { hist[b[i] & 0xF]++; hist[b[i] >> 4]++; }
  Serial.println("Nibble-Histogramm (Rohwerte vom Bus):");
  for (int v = 0; v < 16; v++) Serial.printf("  %2d : %lu\r\n", v, (unsigned long)hist[v]);
  Serial.printf("Bridge: %lu Frames ok, %lu Timeouts, Anzeige %lu fps\r\n",
    (unsigned long)frames_ok, (unsigned long)frames_to, (unsigned long)fps_shown);
}
static void hexdump_range(uint32_t start, uint32_t len) {
  const uint8_t *b = (const uint8_t *)framebuf;
  uint32_t n = words_captured * 4;
  for (uint32_t off = start; off < start + len && off < n; off += 16) {
    Serial.printf("%06lX: ", (unsigned long)off);
    for (int i = 0; i < 16 && off + i < n; i++) Serial.printf("%02X ", b[off + i]);
    Serial.println();
  }
}
static void cmd_pgm() {
  if (words_captured * 4 < FRAME_BYTES) { Serial.println("Kein kompletter Frame."); return; }
  const uint8_t *b = (const uint8_t *)framebuf;
  Serial.println("### PGM BEGIN ###");
  Serial.println("P2");
  Serial.printf("# PicoGSC v%s Rohframe (QuickDraw-Polaritaet!), Nibble %s, Flanke %s\r\n",
                PICOGSC_VERSION, nib_hi_first ? "HI" : "LO", edge_fall ? "FALL" : "RISE");
  Serial.println("640 400"); Serial.println("15");
  int col = 0;
  for (uint32_t i = 0; i < FRAME_BYTES; i++) {
    uint8_t by = b[i];
    uint8_t p1 = nib_hi_first ? (by >> 4) : (by & 0xF);
    uint8_t p2 = nib_hi_first ? (by & 0xF) : (by >> 4);
    Serial.printf("%d %d ", p1, p2);
    if (++col >= 16) { Serial.println(); col = 0; }
  }
  if (col) Serial.println();
  Serial.println("### PGM END ###");
}
static void cmd_inputs() {
  uint32_t hm = 0, hb = 0; const uint32_t N = 10000;
  for (uint32_t i = 0; i < N; i++) {
    if (gpio_get(PIN_MF)) hm++;
    if (gpio_get(PIN_BLANK)) hb++;
    delayMicroseconds(10);
  }
  Serial.printf("M_F: %.1f%% high | DISP_BLANK: %.1f%% high | FLM: %.1f Hz (grob!)\r\n",
                100.0f * hm / N, 100.0f * hb / N, flm_hz(100));
}
static void cmd_help() {
  Serial.println(
    "c Capture | v Verify(CRC) | s Statistik | d/D Hexdump | l <n> Zeile\r\n"
    "p PGM(roh) | n Nibble | e Flanke | i Pegel/FLM | t Testbild | g Bridge | h Hilfe");
  Serial.printf("Flanke %s | Nibble %s | Bridge %s\r\n",
    edge_fall ? "FALL" : "RISE", nib_hi_first ? "HI" : "LO", live_mode ? "AN" : "AUS");
}

// ---------- Arduino ----------
void setup() {
  Serial.begin(115200);
  uint32_t t0 = millis();
  while (!Serial && millis() - t0 < 2000) {}   // Bridge laeuft auch standalone

  if (!display.begin()) {
    pinMode(LED_BUILTIN, OUTPUT);
    for (;;) {
      Serial.println("PicoGSC: display.begin() FEHLGESCHLAGEN (RAM? Aufloesung?)");
      digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
      delay(500);
    }
  }
  init_palette();
  setup_capture_hw();

  Serial.printf("\r\n== PicoGSC v%s — PowerBook 180 GSC -> HDMI ==\r\n", PICOGSC_VERSION);
  Serial.println("   https://picogsc.com");
  cmd_help();
  draw_nosignal();
}

void loop() {
  // ---- CLI ----
  static char line[32]; static uint8_t pos = 0;
  while (Serial.available()) {
    char ch = Serial.read();
    if (ch == '\r' || ch == '\n') {
      line[pos] = 0;
      if (pos) {
        char cmd = line[0];
        int arg = (pos > 1) ? atoi(line + 1) : -1;
        switch (cmd) {
          case 'c': capture_frame(500); print_status_line(); break;
          case 'v': cmd_verify(); break;
          case 's': cmd_stats(); break;
          case 'd': hexdump_range(0, 512); break;
          case 'D': hexdump_range(0, words_captured * 4); break;
          case 'l': if (arg >= 0 && arg < LINES) hexdump_range((uint32_t)arg * LINE_BYTES, LINE_BYTES); break;
          case 'p': cmd_pgm(); break;
          case 'n': nib_hi_first = !nib_hi_first; Serial.printf("Nibble: %s\r\n", nib_hi_first ? "HI" : "LO"); break;
          case 'e': unload_program(); edge_fall = !edge_fall; load_program();
                    Serial.printf("Flanke: %s\r\n", edge_fall ? "FALL" : "RISE"); break;
          case 'i': cmd_inputs(); break;
          case 't': live_mode = false; draw_testpattern(); break;
          case 'g': live_mode = !live_mode; screen = SCR_NONE;
                    Serial.printf("Bridge: %s\r\n", live_mode ? "AN" : "AUS"); break;
          default:  cmd_help(); break;
        }
      }
      pos = 0;
    } else if (pos < sizeof(line) - 1) line[pos++] = ch;
  }

  if (!live_mode) { delay(10); return; }

  // ---- Bridge ----
  if (capture_frame(200)) {
    frames_ok++;
    if (screen != SCR_LIVE) {
      display.fillScreen(15); screen = SCR_LIVE;
      fps_last_ms = millis(); fps_count = 0;
    }
    blit_frame();
    fps_count++;
    uint32_t now = millis();
    if (now - fps_last_ms >= 1000) {
      fps_shown = fps_count; fps_count = 0; fps_last_ms = now;
      char buf[80];
      float hz = flm_hz(50);
      snprintf(buf, sizeof(buf), "PicoGSC LIVE | FLM ~%.0f Hz (%s) | %lu fps",
               hz, hz > 85 ? "ROM" : "OS", (unsigned long)fps_shown);
      draw_statusbar(buf, C_GREEN);
    }
  } else {
    frames_to++;
    if (!signal_present()) {
      if (screen != SCR_NOSIG) draw_nosignal();
      delay(300);
    } else if (screen == SCR_LIVE) {
      draw_statusbar("SYNC DA, CAPTURE LEER - Flanke ('e') / Datenleitungen pruefen", C_YELLOW);
    }
  }
}

/*
 * ================= ANHANG: gemessene GSC-Busspezifikation ===============
 * Aufloesung        640 x 400
 * Farbtiefe         4 bpp linear (kein Dual-Scan)
 * Bytes/Zeile       320 (exakt)
 * Zeilen/Frame      400 (exakt), kein Vertical Blanking
 * Framebuffer       128 000 Byte
 * CL2 im Burst      ~15,7 MHz (31,3344 MHz GSC-Oszillator / 2)
 * CL2 Zeilenmittel  13,06 MHz | Burst ~20,4 us
 * CL1               ~40,8 kHz
 * FLM               modusabhaengig: exakt 102 Hz im ROM-Boot-Screen,
 *                   69,9 Hz mit geladenem OS (16 Graustufen).
 *                   Burstlaenge bleibt gleich, die Pause dazwischen variiert.
 * Logikpegel        5 V
 * M_F               statisch high (gemessen)
 * Polaritaet        hoher Nibble-Wert = dunkel (QuickDraw-Konvention)
 * LSB-Befund        nur Werte 0/4/8/14 im ganzen Frame — Bit 0 jedes Nibbles
 *                   bleibt low. 5-V-seitige Gegenpruefung an FPDATA0/FPDATA4
 *                   steht noch aus (Verdrahtungsfehler nicht ausgeschlossen).
 */
