# Sample captures

Raw frames straight from the GSC bus, exported with the `p` command as ASCII
PGM (P2, 640x400, maxval 15).

**These are raw bus values, i.e. QuickDraw polarity: a higher value means
darker.** Most image viewers will therefore show them inverted. To view them
the way the panel does:

```sh
magick frame.pgm -negate frame.png
```

The firmware applies this inversion in the display palette, so what you see on
the HDMI output is already correct — only the exported files are raw, on
purpose, so they remain faithful bus data.

## Files

| File | Content |
|---|---|
| `bootscreen.pgm` | ROM boot screen (blinking floppy), FLM = 102 Hz |
| `desktop.pgm` | System 7 desktop, FLM = 69.9 Hz |

*(add your own captures here)*
