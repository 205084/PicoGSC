Put project photos here.

Suggested:
- `setup.jpg`     - the breadboard build, 245s at the PowerBook connector
- `live.jpg`      - PowerBook and monitor side by side, same image
- `testpattern.jpg` - grey wedge + checkerboard on the monitor

Use PNG for screen captures: JPEG compression smears the 1-pixel dithering,
which is exactly the detail that proves the capture is byte-exact.
